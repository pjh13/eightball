#!/bin/bash

# This script is to be run after cloning the repo into a new directory
# This will configure the repository with the 'ignore' merge driver
git config merge.ignore.driver true

