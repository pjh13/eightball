#!/bin/bash
# This script pulls the latest changes from the main sample repository
git pull "https://github.com/fortify/sample-eightball.git" --allow-unrelated-histories --no-edit
